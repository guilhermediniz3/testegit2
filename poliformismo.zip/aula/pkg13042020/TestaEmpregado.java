 
package aula.pkg13042020;
 
public class TestaEmpregado {
 
    public static void main(String[] args) {
        Empresa empresa = new Empresa();
        
     
        
        Empregado emp = new Empregado("Maria dos Santos", 1550, 2001);
        empresa.adicionaEmpregado( emp );
                
        empresa.adicionaEmpregado( new Empregado("José da Silva", 1000, 2000) );
        
        empresa.adicionaEmpregado( new Empregado("Antonio Pereira", 2000, 2004) );
        
           Gerente chefe = new Gerente("João da Silva", 3000, 2005);
        chefe.setNomeSecretaria("Maria");
        empresa.adicionaEmpregado(chefe);
        
        empresa.reajustaSalarios(10);
        
        System.out.println( empresa.mostraEmpregados() );
    }
    
}
