package aula.pkg13042020;

public class Empregado {
    private String nome;
    private double salario;
    private int anoContratacao;
    public final int ANO_BASE = 2020;

    public Empregado(String nome, double salario, int anoContratacao){
        this.nome = nome;
        this.salario = salario;
        this.anoContratacao = anoContratacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getAnoContratacao() {
        return anoContratacao;
    }

    public void setAnoContratacao(int anoContratacao) {
        this.anoContratacao = anoContratacao;
    }
    
    

    public void reajustaSalario(double porcentagem){
        setSalario(getSalario() + (porcentagem / 100 * getSalario()));
    }

    @Override	
    public String toString(){
        return "\n" + nome + " - " + getSalario() + " - " + getAnoContratacao();
    }
}
