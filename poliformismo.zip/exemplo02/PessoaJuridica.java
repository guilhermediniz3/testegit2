package exemplo02;

public class PessoaJuridica extends Pessoa {
    
    private String cnpj;
    
    public PessoaJuridica( String nome, String endereco, String telefone, String cnpj  ){
        super( nome, endereco, telefone );
        this.cnpj = cnpj;
    }
    
    @Override
    public String toString(){
        return super.toString() +
                "\nCNPJ: " + cnpj;        
    }
    
    public void setCnpj( String cnpj ){
        this.cnpj = cnpj;
    }
    
    public String getCnpj(){
        return this.cnpj;
    }
    
}
