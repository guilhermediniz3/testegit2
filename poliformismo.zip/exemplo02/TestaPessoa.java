package exemplo02;

public class TestaPessoa {

    public static void main(String[] args) {

        Pessoa[] lista = new Pessoa[4];
        
        lista[0] = new PessoaFisica("Maria Beatria", "Rua A", "(31)9987-4234", "012.123.456-00");
        lista[1] = new PessoaFisica("José da Silva", "Rua B", "(31)9987-4234", "123.222.323-22");
        
        lista[2] = new PessoaJuridica("Costa e Silva Ltda", "Rua C", "(31)9987-4234", "02.234.323/0001-23");
        lista[3] = new PessoaJuridica("Supermercados Limitado", "Rua C", "(31)9987-4234", "02.234.323/0001-23");
        
        
        for( int i = 0; i < 4; i++ ){
            System.out.println(lista[i]);
        }

    }
    
}
