package exemplo02;

public class PessoaFisica extends Pessoa {
   
    protected String cpf;
    
    public PessoaFisica( String nome, String endereco, String telefone, String cpf  ){
        super( nome, endereco, telefone );
        this.cpf = cpf;
    }
    
    @Override
    public String toString(){
        return super.toString() +
                "\nCPF: " + cpf;        
    }
    
    public void setCpf( String cpf ){
        this.cpf = cpf;
    }
    
    public String getCpf(){
        return this.cpf;
    }
}
