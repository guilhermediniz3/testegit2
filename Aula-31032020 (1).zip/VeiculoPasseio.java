public class VeiculoPasseio extends Veiculo {
    
    private int numeroPassageiros;
    
    public void setNumeroPassageiros( int numeroPassageiros ){
        this.numeroPassageiros = numeroPassageiros;
    }
    
    public int getNumeroPassageiros(){
        return this.numeroPassageiros;
    }
    
}
