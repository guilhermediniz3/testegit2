public class TesteVeiculo {

    public static void main(String[] args) {
     
        VeiculoPasseio vp = new VeiculoPasseio();
        vp.setAno(2020);
        vp.setPlaca("HBC-1234");
        vp.setNumeroPassageiros(5);
        
        
    }
    
}
