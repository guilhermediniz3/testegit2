package henra�a3.Pessoa;

public class Amigos  {



	
}
