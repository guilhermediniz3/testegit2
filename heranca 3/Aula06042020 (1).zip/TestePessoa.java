public class TestePessoa {
    public static void main(String[] args){
        
    Parente parente = new Parente("Amanda", "(31)2332-3456", "Rua Vale, 1234", "025.361.444-23", "Irmã");
    parente.exibe();
    }
}
