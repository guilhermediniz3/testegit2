

public class VeiculoPasseio extends Veiculo {
    
    public VeiculoPasseio( String placa ){
        super(placa);
    }
}
