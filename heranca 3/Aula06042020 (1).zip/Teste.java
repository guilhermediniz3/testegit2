 
public class Teste {
    
        public static void main(String[] args){
            
            Veiculo v = new Veiculo("HAB-2342");
          
            VeiculoPasseio vp = new VeiculoPasseio("kcx-2345");
            
        }
}
